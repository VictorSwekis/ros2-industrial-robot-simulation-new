// generated from rosidl_typesupport_fastrtps_c/resource/idl__rosidl_typesupport_fastrtps_c.h.em
// with input from conveyorbelt_msgs:msg/ConveyorBeltState.idl
// generated code does not contain a copyright notice
#ifndef CONVEYORBELT_MSGS__MSG__DETAIL__CONVEYOR_BELT_STATE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
#define CONVEYORBELT_MSGS__MSG__DETAIL__CONVEYOR_BELT_STATE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_


#include <stddef.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "conveyorbelt_msgs/msg/rosidl_typesupport_fastrtps_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_conveyorbelt_msgs
size_t get_serialized_size_conveyorbelt_msgs__msg__ConveyorBeltState(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_conveyorbelt_msgs
size_t max_serialized_size_conveyorbelt_msgs__msg__ConveyorBeltState(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_FASTRTPS_C_PUBLIC_conveyorbelt_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_c, conveyorbelt_msgs, msg, ConveyorBeltState)();

#ifdef __cplusplus
}
#endif

#endif  // CONVEYORBELT_MSGS__MSG__DETAIL__CONVEYOR_BELT_STATE__ROSIDL_TYPESUPPORT_FASTRTPS_C_H_
