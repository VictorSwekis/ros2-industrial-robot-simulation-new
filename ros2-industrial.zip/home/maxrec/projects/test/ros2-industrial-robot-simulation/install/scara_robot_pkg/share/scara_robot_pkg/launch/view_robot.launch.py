from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import Command, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    pkg = get_package_share_directory('scara_robot_pkg')

    use_gui = DeclareLaunchArgument(
        'use_gui',
        default_value='true',
        description='Use joint_state_publisher_gui to move joints'
    )

    urdf_file = PathJoinSubstitution([pkg, 'urdf', 'scara_assembly.urdf'])

    robot_description = ParameterValue(Command(['cat ', urdf_file]), value_type=str)

    # Publishes /joint_states from sliders 
    jsp_gui = Node(
        condition=None,  # let GUI be controlled by launch arg
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        name='joint_state_publisher_gui',
        arguments=[],
        parameters=[{'rate': 30.0}],
        emulate_tty=True
    )

    # Publishes TF from the URDF
    rsp = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        parameters=[{'robot_description': robot_description}],
        output='screen'
    )

    # Opening RViz and give a default view
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', PathJoinSubstitution([pkg, 'rviz', 'default_view.rviz'])],
        output='screen'
    )

    return LaunchDescription([
        use_gui,
        jsp_gui,
        rsp,
        rviz
    ])
